export default {
  addCart (state, payload) {
    state.cartCount = payload.count
  }
}
