<template>
  <div>
    <h3>Welcome</h3>
  </div>
</template>

<script>
export default {

}
</script>

<style lang="less" scoped>

</style>